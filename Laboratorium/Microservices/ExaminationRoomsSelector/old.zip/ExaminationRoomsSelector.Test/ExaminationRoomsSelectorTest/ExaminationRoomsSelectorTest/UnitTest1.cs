using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExaminationRoomsSelectorTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
